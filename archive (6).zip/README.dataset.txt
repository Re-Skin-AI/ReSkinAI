# facialai > 2024-02-24 1:48pm
https://universe.roboflow.com/facialai-nfkit/facialai

Provided by a Roboflow user
License: CC BY 4.0

